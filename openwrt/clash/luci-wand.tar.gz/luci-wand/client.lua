local uci = require("luci.model.uci").cursor()

l = SimpleForm("wand")
l.title = translate("Login")
l.reset = false
l.submit = false
l:section(SimpleSection).template  = "wand/login"

m = SimpleForm("wand",translate("Wand"))
m.description = translate("Welcome to wand!")
m.reset = false
m.submit = false

w = SimpleForm("wand")
w.reset = false
w.submit = false
w:section(SimpleSection).template  = "wand/dashboard"

if uci:get("wand", "config", "token") then
	return m, w
else
	return l
end