module("luci.controller.wand", package.seeall)

function index()
    entry({"admin", "services", "wand_client"}, form("wand/client"), _("Wand"), 1).leaf = true
	entry({"admin", "services", "wand_login"}, call("auth_login"))
	entry({"admin", "services", "wand_info"}, call("user_info"))
	entry({"admin", "services", "wand_start"}, call("user_start"))
	entry({"admin", "services", "wand_stop"}, call("user_stop"))
	entry({"admin", "services", "wand_restart"}, call("user_restart"))
	entry({"admin", "services", "wand_subscribe"}, call("user_subscribe"))
	entry({"admin", "services", "wand_logout"}, call("user_logout"))
	entry({"admin", "services", "clash_update"}, call("action_clash_update"))
end

local uci = require("luci.model.uci").cursor()
local json = require "luci.jsonc"

local function daip()
	local daip = luci.sys.exec("uci -q get network.lan.ipaddr |awk -F '/' '{print $1}' 2>/dev/null |tr -d '\n'")
	if not daip or daip == "" then
		local daip = luci.sys.exec("ip address show $(uci -q -p /tmp/state get network.lan.ifname) | grep -w 'inet'  2>/dev/null |grep -Eo 'inet [0-9\.]+' | awk '{print $2}' | tr -d '\n'")
	end
	if not daip or daip == "" then
		local daip = luci.sys.exec("ip addr show 2>/dev/null | grep -w 'inet' | grep 'global' | grep 'brd' | grep -Eo 'inet [0-9\.]+' | awk '{print $2}' | head -n 1 | tr -d '\n'")
	end
	return daip
end

local function wand_login()
	local email = luci.http.formvalue("email")
	local password = luci.http.formvalue("password")
	if email and password then
		info = json.parse(luci.sys.exec(string.format("curl -k -X POST -d email=%s -d password=%s https://d.wanc.cc/login.php", email, password)))
		if info and info.data then
			luci.sys.exec(string.format('wget --no-check-certificate -O /etc/wand/config.yaml "https://d.wanc.cc/openwrt.php?token=%s"', info.data.token))
			uci:set("wand", "config", "token", info.data.token)
			uci:set("wand", "config", "name", info.data.name)
			uci:commit("wand")
			return "success"
		else
			return info.message
		end
	else
		return "login faild"
	end
end

local function wand_start()
	info = luci.sys.exec('/etc/init.d/wand start')
	return info
end	

local function wand_restart()
	info = luci.sys.exec('/etc/init.d/wand restart')
	return info
end	

local function wand_stop()
	luci.sys.exec('/etc/init.d/wand disable')
	uci:set("wand", "config", "enable", 1)
	uci:commit("wand")
	info = luci.sys.exec('/etc/init.d/wand stop')
	return info
end	

local function wand_subscribe()
	local token = uci:get("wand", "config", "token")
	if token then
		luci.sys.exec(string.format('wget --no-check-certificate -O /etc/wand/config.yaml "https://d.wanc.cc/openwrt.php?token=%s"', token))
		return "订阅更新成功"
	else
		return "login faild"
	end
end

local function wand_logout()
	luci.sys.exec('/etc/init.d/wand disable')
	luci.sys.exec('/etc/init.d/wand stop')
	uci:set("wand", "config", "enable", 1)
	uci:delete("wand", "config", "token")
	uci:delete("wand", "config", "name")
	uci:commit("wand")
	return "success"
end

local function wand_info()
	info = {};
	info.name = uci:get("wand", "config", "name")
	info.enable = uci:get("wand", "config", "enable")
	info.port = uci:get("wand", "config", "port")
	info.socks_port = uci:get("wand", "config", "socks_port")
	info.dns_listen = uci:get("wand", "config", "dns_listen")
	info.ip = daip()
	info.external_controller = uci:get("wand", "config", "external_controller")
	info.secret = uci:get("wand", "config", "secret")
	info.external_ui = uci:get("wand", "config", "external_ui")
	info.clash_v = luci.sys.exec('/etc/wand/clash -v')
	return info
end

local function clash_update()
	local enable = uci:get("wand", "config", "enable")
	local clash_url = uci:get("wand", "config", "clash_url")
	local custom_url = uci:get("wand", "config", "custom_url")
	if clash_url and custom_url then
		if enable == "0" then
			return "系统正在运行，停止后更新"
		else
			luci.sys.exec(string.format('wget --no-check-certificate -O /etc/wand/clash "%s"', clash_url))
			luci.sys.exec(string.format('wget --no-check-certificate -O /etc/wand/Country.mmdb "%s"', custom_url))
			return "更新内核成功"
		end
	else
		return "更新内核失败"
	end
end

function auth_login()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_login = wand_login();
	})
end

function user_info()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_info = wand_info();
	})
end

function user_start()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_start = wand_start();
	})
end

function user_stop()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_stop = wand_stop();
	})
end

function user_restart()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_restart = wand_restart();
	})
end

function user_subscribe()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_subscribe = wand_subscribe();
	})
end

function user_logout()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		wand_logout = wand_logout();
	})
end

function action_clash_update()
	luci.http.prepare_content("application/json")
	luci.http.write_json({
		clash_update = clash_update();
	})
end